package problem1;

public class debitCard {
	public String varification() {
		// TODO Auto-generated method stub
		
		return "debitCard";
	}
	public boolean paymentProcess(double totalCost) {
		// TODO Auto-generated method stub
		return true;
	}

}
