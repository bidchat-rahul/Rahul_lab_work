package problem1;

public class cashOnDelivery {

	public String varification() {
		// TODO Auto-generated method stub
		
		return "COD";
	}

	public boolean paymentProcess(double totalCost) {
		// TODO Auto-generated method stub
		return true;
	}
	

}
