package problem1;

public class netBanking {
	public String varification() {
		// TODO Auto-generated method stub
		
		return "netBanking";
	}
	public boolean paymentProcess(double totalCost) {
		// TODO Auto-generated method stub
		return true;
	}

}
