package problem1;

public class creditCard {

	public String varification() {
		// TODO Auto-generated method stub
		
		return "creditCard";
	}

	public boolean paymentProcess(double totalCost) {
		// TODO Auto-generated method stub
		return true;
	}
}
