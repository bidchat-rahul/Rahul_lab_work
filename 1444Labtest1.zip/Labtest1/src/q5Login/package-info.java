/**
 * 
 */
/**
 * @author rahul
 *
 */
package q5Login;

/*
5. You have an online banking account for your actual bank account. Basic transactions such as 
getBalance(), withdraw( int amount), deposit(int amount) etc can be performed through both these options.
 In addition the online account must have a secure login procedure and each of the basic transactions could be
  perfomed through online account only if you have logged in successfully. 

*/