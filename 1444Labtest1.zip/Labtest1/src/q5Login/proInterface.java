package q5Login;

public interface proInterface {
	
	public int getBalance();
	public void withdrow(int bal);
	public void deposit(int bal);
	

}
