package Labtest1Q1;

public class desal implements enginType {

	@Override
	public void getFuel() {
		// TODO Auto-generated method stub
		System.out.println("Fill disal now");
		
	}

}
