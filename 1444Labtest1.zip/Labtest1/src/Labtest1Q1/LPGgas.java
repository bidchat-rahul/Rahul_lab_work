package Labtest1Q1;

public class LPGgas {
	
	public void getLPG(){
		System.out.println("Now fill LPG cyclinder");
	}

}
