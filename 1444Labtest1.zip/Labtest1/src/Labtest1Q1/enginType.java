package Labtest1Q1;

public interface enginType {
	
	public void getFuel();
}
