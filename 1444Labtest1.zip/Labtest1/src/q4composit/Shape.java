package q4composit;

public interface Shape {
	
	public void drow();

}
