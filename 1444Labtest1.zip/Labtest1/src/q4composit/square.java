package q4composit;

public class square implements Shape {

	@Override
	public void drow() {
		// TODO Auto-generated method stub
		System.out.println("Squar has been drown");
	}
}


