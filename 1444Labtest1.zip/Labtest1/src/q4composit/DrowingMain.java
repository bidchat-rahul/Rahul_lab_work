package q4composit;

public class DrowingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DrowShape ds = new DrowShape();
		
		ds.drow();
		ds.crateShape("tri");
		ds.drowShap();
		ds.drow();
		ds.crateShape("sqa");
		ds.drowShap();
		ds.drow();
		ds.crateShape("cir");
		ds.drowShap();
		
	}

}
