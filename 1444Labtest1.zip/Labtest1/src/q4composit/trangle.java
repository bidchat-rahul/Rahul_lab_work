package q4composit;

public class trangle implements Shape {

	@Override
	public void drow() {
		// TODO Auto-generated method stub
		System.out.println("Tringle has been drown");
	}

}
