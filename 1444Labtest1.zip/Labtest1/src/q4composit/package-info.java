/**
 * 
 */
/**
 * @author rahul
 *
 */
package q4composit;
/*
4. Consider a graphical drawing editor which provides basic shapes such as circle, triangle 
and square as elements for drawing. The editor allows you to embed these elements within one another 
to any depth. Ex. You can create a ring of concentric circles or squares or triangles as well as have a 
circle within a triangle within a square. Possibilities are unlimited.
(composit)
*/